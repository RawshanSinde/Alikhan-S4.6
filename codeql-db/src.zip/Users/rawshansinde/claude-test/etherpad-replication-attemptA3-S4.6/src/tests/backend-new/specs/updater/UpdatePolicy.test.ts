import {describe, it, expect} from 'vitest';
import {evaluatePolicy} from '../../../../node/updater/UpdatePolicy';
import {InstallMethod, Tier} from '../../../../node/updater/types';

const baseInput = {
  installMethod: 'git' as Exclude<InstallMethod, 'auto'>,
  tier: 'manual' as Tier,
  current: '2.7.1',
  latest: '2.7.2',
  // Default to a valid window so tier-4 cases below can assert canAutonomous
  // without also having to wire a window each time. The "no window" + "invalid
  // window" cases set this explicitly.
  maintenanceWindow: {start: '03:00', end: '05:00', tz: 'local' as const},
};

describe('evaluatePolicy', () => {
  it('off tier denies everything', () => {
    const r = evaluatePolicy({...baseInput, tier: 'off'});
    expect(r).toEqual({canNotify: false, canManual: false, canAuto: false, canAutonomous: false, reason: 'tier-off'});
  });

  it('notify tier allows only notify', () => {
    const r = evaluatePolicy({...baseInput, tier: 'notify'});
    expect(r.canNotify).toBe(true);
    expect(r.canManual).toBe(false);
    expect(r.canAuto).toBe(false);
    expect(r.canAutonomous).toBe(false);
  });

  it('manual tier allows notify+manual on git', () => {
    const r = evaluatePolicy({...baseInput, tier: 'manual'});
    expect(r.canManual).toBe(true);
    expect(r.canAuto).toBe(false);
  });

  it('manual tier denies manual on docker', () => {
    const r = evaluatePolicy({...baseInput, tier: 'manual', installMethod: 'docker'});
    expect(r.canNotify).toBe(true);
    expect(r.canManual).toBe(false);
    expect(r.reason).toBe('install-method-not-writable');
  });

  it('autonomous tier allows everything on git', () => {
    const r = evaluatePolicy({...baseInput, tier: 'autonomous'});
    expect(r).toEqual({canNotify: true, canManual: true, canAuto: true, canAutonomous: true, reason: 'ok'});
  });

  it('autonomous on managed install denies write tiers', () => {
    const r = evaluatePolicy({...baseInput, tier: 'autonomous', installMethod: 'managed'});
    expect(r.canNotify).toBe(true);
    expect(r.canManual).toBe(false);
    expect(r.canAuto).toBe(false);
    expect(r.canAutonomous).toBe(false);
  });

  it('current === latest denies all (nothing to do)', () => {
    const r = evaluatePolicy({...baseInput, tier: 'autonomous', current: '2.7.2', latest: '2.7.2'});
    expect(r.canNotify).toBe(false);
    expect(r.canManual).toBe(false);
    expect(r.reason).toBe('up-to-date');
  });

  it('current > latest (dev build) denies all', () => {
    const r = evaluatePolicy({...baseInput, tier: 'autonomous', current: '3.0.0', latest: '2.7.2'});
    expect(r.canNotify).toBe(false);
    expect(r.reason).toBe('up-to-date');
  });
});

describe('evaluatePolicy terminal-state gating', () => {
  it('rollback-failed denies auto/autonomous but keeps manual on', () => {
    const r = evaluatePolicy({
      ...baseInput, tier: 'autonomous',
      executionStatus: 'rollback-failed',
    });
    expect(r.canNotify).toBe(true);
    expect(r.canManual).toBe(true);
    expect(r.canAuto).toBe(false);
    expect(r.canAutonomous).toBe(false);
    expect(r.reason).toBe('rollback-failed-terminal');
  });

  it('idle execution behaves identically to no-status', () => {
    const r = evaluatePolicy({...baseInput, tier: 'autonomous', executionStatus: 'idle'});
    expect(r.canManual).toBe(true);
    expect(r.canAuto).toBe(true);
    expect(r.canAutonomous).toBe(true);
    expect(r.reason).toBe('ok');
  });

  it('preflight-failed does NOT block manual / auto (it is informational only)', () => {
    const r = evaluatePolicy({
      ...baseInput, tier: 'autonomous', executionStatus: 'preflight-failed',
    });
    expect(r.canManual).toBe(true);
    expect(r.canAuto).toBe(true);
    expect(r.canAutonomous).toBe(true);
  });
});

describe('evaluatePolicy tier 4 — maintenance window gating', () => {
  it('autonomous without a window degrades to canAuto only', () => {
    const r = evaluatePolicy({
      ...baseInput, tier: 'autonomous', maintenanceWindow: null,
    });
    expect(r.canManual).toBe(true);
    expect(r.canAuto).toBe(true);
    expect(r.canAutonomous).toBe(false);
    expect(r.reason).toBe('maintenance-window-missing');
  });

  it('autonomous with a malformed window degrades to canAuto only', () => {
    const r = evaluatePolicy({
      ...baseInput, tier: 'autonomous',
      maintenanceWindow: {start: 'oops', end: '05:00', tz: 'local'},
    });
    expect(r.canAutonomous).toBe(false);
    expect(r.reason).toBe('maintenance-window-invalid');
  });

  it('lower tiers ignore the maintenance window (reason stays ok)', () => {
    const r = evaluatePolicy({
      ...baseInput, tier: 'auto', maintenanceWindow: null,
    });
    expect(r.canAuto).toBe(true);
    expect(r.canAutonomous).toBe(false);
    expect(r.reason).toBe('ok');
  });

  it('rollback-failed still wins over the window denial', () => {
    const r = evaluatePolicy({
      ...baseInput, tier: 'autonomous',
      maintenanceWindow: null,
      executionStatus: 'rollback-failed',
    });
    expect(r.canAuto).toBe(false);
    expect(r.canAutonomous).toBe(false);
    expect(r.reason).toBe('rollback-failed-terminal');
  });
});
